
<?php
		$this->pagecounter->run_counter('page');
?>
</body>
</html>