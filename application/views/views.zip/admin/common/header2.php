<!DOCTYPE html>

<html lang="en" class="no-js">
   
    <head>
        <meta charset="utf-8"/>
        <title>C-FarmIs</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="refresh" content="120" >
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta content="FlameOnePage freebie theme for web startups by FairTech SEO." name="description"/>
        <meta content="FairTech" name="author"/>
        <link href="http://fonts.googleapis.com/css?family=Hind:300,400,500,600,700" rel="stylesheet" type="text/css">

       <link href="<?=base_url('assets/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">
        <link href="<?=base_url('assets/bootstrap');?>/css/font-awesome.css" rel="stylesheet">
        <link href="<?=base_url('assets/css/animate.css');?>" rel="stylesheet">
        <link rel="shortcut icon" href="<?=base_url('public/images/favicon.png');?>"/>


            <?php // add css files
      /*  $this->minify->css(array('default.css', 'admin.css'));
        echo $this->minify->deploy_css();
/*
        $this->minify->js(array('helpers.js', 'jqModal.js'));
        echo $this->minify->deploy_js(FALSE, 'custom_js_name.min.js');*/

    ?>

        <link rel="shortcut icon" href="favicon.ico"/>
        
        <!-- CORE PLUGINS -->
        <script src="<?=base_url('assets/js/jquery-1.11.0.min.js');?>" type="text/javascript"></script>
        <script src="<?=base_url('assets/bootstrap/js/bootstrap.min.js');?>" type="text/javascript"></script>
        <script src="<?=base_url('assets/js/jquery-migrate.min.js');?>" type="text/javascript"></script>
        <!-- PAGE LEVEL PLUGINS -->
        <script src="<?=base_url('assets/js/jquery-migrate.min.js');?>" type="text/javascript"></script>
    </head>
   
  
    <body id="body" data-spy="scroll" data-target=".header" class="home">