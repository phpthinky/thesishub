<div class="container content">
<div class="row">
  <div class="col-sm-4 col-sm-push-8">Sidebar</div>
  <div class="col-sm-8 col-sm-pull-4">Content -></div>
</div>
</div>